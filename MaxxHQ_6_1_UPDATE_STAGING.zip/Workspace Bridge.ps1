﻿$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$cfgPath=Join-Path $root 'settings.json'
$log=Join-Path $root 'Workspace-errors.log'
function Log([string]$line){Add-Content -LiteralPath $log -Value ((Get-Date -Format o)+': '+$line)}
function Reply($ctx,[int]$status,$obj){$bytes=[Text.Encoding]::UTF8.GetBytes(($obj|ConvertTo-Json -Depth 30 -Compress));$ctx.Response.StatusCode=$status;$ctx.Response.ContentType='application/json; charset=utf-8';$ctx.Response.ContentLength64=$bytes.Length;$ctx.Response.OutputStream.Write($bytes,0,$bytes.Length);$ctx.Response.Close()}
function Normalize-Website([string]$value) {
 $v=$value.Trim()
 if(-not $v){return ''}
 if($v -notmatch '^https?://'){$v='https://'+$v}
 $uri=$null
 if(-not [Uri]::TryCreate($v,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -notin @('http','https') -or $uri.Host -notmatch '\.' -or $v -match '\s'){throw 'Invalid website address. Try www.example.com'}
 return $uri.AbsoluteUri
}
function EdgePath { @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe","${env:ProgramFiles}\Microsoft\Edge\Application\msedge.exe","${env:LOCALAPPDATA}\Microsoft\Edge\Application\msedge.exe") | Where-Object {Test-Path -LiteralPath $_} | Select-Object -First 1 }
# Restrict listener to the user's local machine and random free port.
$socket=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0);$socket.Start();$port=$socket.LocalEndpoint.Port;$socket.Stop()
$server=[Net.HttpListener]::new();$server.Prefixes.Add("http://127.0.0.1:$port/");$server.Start()
$url="http://127.0.0.1:$port/"
$edge=EdgePath
if(-not $edge){throw 'Microsoft Edge not found.'}
# Use the default Edge profile; no custom profile, no saved credentials inside this project.
Start-Process -FilePath $edge -ArgumentList @("--app=$url","--window-size=1240,930")

try {
 while ($server.IsListening) {
  $ctx=$server.GetContext()
  try {
   $path=$ctx.Request.Url.AbsolutePath
   if($path -eq '/' -and $ctx.Request.HttpMethod -eq 'GET') {
    $bytes=[IO.File]::ReadAllBytes((Join-Path $root 'dashboard.html'));$ctx.Response.ContentType='text/html; charset=utf-8';$ctx.Response.ContentLength64=$bytes.Length;$ctx.Response.OutputStream.Write($bytes,0,$bytes.Length);$ctx.Response.Close();continue
   }
   # Serve bundled visual assets to the local dashboard (previously returned 404).
   if($ctx.Request.HttpMethod -eq 'GET' -and $path -match '^/(favicon\.png|maxxhq-wordmark\.png|icons/[a-z0-9_-]+\.(svg|png))$') {
    $relative=$path.TrimStart('/').Replace('/',[IO.Path]::DirectorySeparatorChar)
    $asset=Join-Path $root $relative
    if([IO.File]::Exists($asset)) {
     $bytes=[IO.File]::ReadAllBytes($asset)
     $ctx.Response.ContentType=if($asset.EndsWith('.svg')){'image/svg+xml'}elseif($asset.EndsWith('.png')){'image/png'}else{'application/octet-stream'}
     $ctx.Response.ContentLength64=$bytes.Length
     $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length);$ctx.Response.Close();continue
    }
   }
   if($path -eq '/api/settings' -and $ctx.Request.HttpMethod -eq 'GET') {Reply $ctx 200 (Get-Content -LiteralPath $cfgPath -Raw | ConvertFrom-Json);continue}
   if($ctx.Request.HttpMethod -ne 'POST'){Reply $ctx 404 @{error='Not found'};continue}
   $origin=[string]$ctx.Request.Headers['Origin']
   if($origin -ne "http://127.0.0.1:$port"){Reply $ctx 403 @{error='Invalid origin'};continue}
   if($ctx.Request.ContentLength64 -gt 262144){Reply $ctx 413 @{error='Request too large'};continue}
   $reader=[IO.StreamReader]::new($ctx.Request.InputStream,[Text.Encoding]::UTF8)
   $raw=$reader.ReadToEnd();$reader.Close()
   $data=$raw|ConvertFrom-Json
   if($path -eq '/api/save') {
    if($null -eq $data.apps -or @($data.apps).Count -gt 40){throw 'Invalid application settings'}
    foreach($a in $data.apps){$a.url=Normalize-Website ([string]$a.url)}
    $data | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $cfgPath -Encoding UTF8
    Reply $ctx 200 $data;continue
   }
   if($path -eq '/api/probe') {
    $current=Get-Content -LiteralPath $cfgPath -Raw|ConvertFrom-Json
    $matched=@($current.apps|Where-Object {([string]$_.id -eq [string]$data.id) -and $_.url})
    if($matched.Count -ne 1){throw 'Unknown configured application'}
    $target=Normalize-Website ([string]$matched[0].url)
    $uri=[Uri]$target
    # A website probe is not proof of authentication or account connectivity.
    $request=[Net.HttpWebRequest]::Create($uri.GetLeftPart([UriPartial]::Authority))
    $request.Method='HEAD';$request.Timeout=4500;$request.AllowAutoRedirect=$false
    $reachable=$false;$message='Website did not respond'
    try {$response=$request.GetResponse();$reachable=$true;$message='Website responded; login not verified';$response.Close()}
    catch [Net.WebException] {
      if($_.Exception.Response){$reachable=$true;$message='Website responded; login not verified';$_.Exception.Response.Close()}
      else {$message='Network check failed; login not verified'}
    }
    Reply $ctx 200 @{reachable=$reachable;message=$message};continue
   }
   if($path -eq '/api/open') {
    $current=Get-Content -LiteralPath $cfgPath -Raw|ConvertFrom-Json
    $match=@($current.apps|Where-Object {($_.url -eq [string]$data.url) -and ([string]$_.url -match '^https?://')})
    if($match.Count -eq 0){throw 'Application URL is not configured'}
    Start-Process -FilePath $edge -ArgumentList @('--new-window',[string]$data.url)
    Reply $ctx 200 @{message='Application launch requested'};continue
   }
   if($path -eq '/api/script') {
    $current=Get-Content -LiteralPath $cfgPath -Raw|ConvertFrom-Json
    $target=[string]$current.scriptTarget
    if(-not $target){throw 'No script configured in settings.json'}
    if($target -match '^https?://') { Start-Process -FilePath $edge -ArgumentList @('--new-window',$target) }
    else {
      $file=[IO.Path]::GetFullPath((Join-Path $root $target))
      if(-not [IO.File]::Exists($file)){throw 'The selected script file is missing'}
      Start-Process -FilePath $edge -ArgumentList @('--new-window',([Uri]$file).AbsoluteUri)
    }
    Reply $ctx 200 @{message='Script launch requested'};continue
   }
   if($path -eq '/api/start') {
    $current=Get-Content -LiteralPath $cfgPath -Raw|ConvertFrom-Json
    $needed=@('gustoUrl','dialerUrl','sunfireUrl','teamsUrl','outlookUrl')
    # Integrate general app list into existing launch keys for the inherited Windows launcher.
    $lookup=@{};foreach($a in $current.apps){$lookup[[string]$a.id]=[string]$a.url}
    foreach($pair in @(@('gusto','gustoUrl'),@('enroll','dialerUrl'),@('sun','sunfireUrl'),@('teams','teamsUrl'),@('outlook','outlookUrl'))){if($lookup.ContainsKey($pair[0])){$current.($pair[1])=$lookup[$pair[0]]}}
    # Run the managed dual-monitor launcher instead of creating five independent windows.
    $current | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $cfgPath -Encoding UTF8
    Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + (Join-Path $root 'Start PING Work.ps1') + '"'))
    Reply $ctx 200 @{message='Dual-monitor workspace launch requested.'};continue
   }
   Reply $ctx 404 @{error='Unknown action'}
  }catch{Log $_.ToString();try{Reply $ctx 400 @{error=$_.Exception.Message}}catch{}}
 }
}finally{$server.Stop();$server.Close()}
