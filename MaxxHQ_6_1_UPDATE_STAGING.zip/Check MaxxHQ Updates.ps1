# MaxxHQ opt-in updater. A manifest URL must be configured by the distributor.
param([switch]$Quiet)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$settingsFile = Join-Path $root 'settings.json'
function Notice($message, $caption='MaxxHQ Updates') {
  Add-Type -AssemblyName System.Windows.Forms
  [Windows.Forms.MessageBox]::Show($message,$caption) | Out-Null
}
try {
  if (-not (Test-Path $settingsFile)) { throw 'settings.json missing' }
  $settings = Get-Content -LiteralPath $settingsFile -Raw | ConvertFrom-Json
  $url = [string]$settings.updateManifestUrl
  if ([string]::IsNullOrWhiteSpace($url)) { if (-not $Quiet) { Notice 'No update source has been configured yet.' }; exit 0 }
  if ($url -notmatch '^https://') { throw 'The update manifest must use HTTPS.' }
  $manifest = Invoke-RestMethod -Uri $url -TimeoutSec 12
  if (-not $manifest.version -or -not $manifest.zipUrl -or -not $manifest.sha256) { throw 'Update manifest is missing version, zipUrl, or sha256.' }
  if ([string]$manifest.zipUrl -notmatch '^https://') { throw 'The update ZIP must use HTTPS.' }
  if ([string]$manifest.sha256 -notmatch '^[a-fA-F0-9]{64}$') { throw 'Invalid SHA-256 checksum.' }
  $current = [string]$settings.version
  if ([string]$manifest.version -eq $current) { if (-not $Quiet) { Notice "MaxxHQ is up to date ($current)." }; exit 0 }
  Add-Type -AssemblyName System.Windows.Forms
  $choice = [Windows.Forms.MessageBox]::Show("An update is available.`n`nInstalled: $current`nAvailable: $($manifest.version)`n`nDownload and install? Your settings and personal links will be preserved.",'MaxxHQ Update Available','YesNo','Question')
  if ($choice -ne 'Yes') { exit 0 }
  $temp = Join-Path $env:TEMP ('MaxxHQ-update-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $temp -Force | Out-Null
  try {
    $zip = Join-Path $temp 'update.zip'
    Invoke-WebRequest -Uri ([string]$manifest.zipUrl) -OutFile $zip -TimeoutSec 90
    $hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash
    if ($hash -ine [string]$manifest.sha256) { throw 'Update verification failed: checksum mismatch.' }
    $stage = Join-Path $temp 'stage'
    Expand-Archive -LiteralPath $zip -DestinationPath $stage -Force
    # Published updates must have a single flat payload root with a launcher.
    if (-not (Test-Path (Join-Path $stage 'OPEN MaxxHQ.vbs'))) { throw 'Update is not a valid MaxxHQ application package.' }
    $backup = Join-Path $temp 'backup'
    New-Item -ItemType Directory -Path $backup | Out-Null
    $exclude = @('settings.json','Workspace-errors.log','Workspace Bridge.log')
    $written = New-Object System.Collections.Generic.List[string]
    $backed = New-Object System.Collections.Generic.List[string]
    try {
      Get-ChildItem -LiteralPath $stage -Recurse -File | ForEach-Object {
        $rel = $_.FullName.Substring($stage.Length).TrimStart('\')
        if ($exclude -contains $rel) { return }
        $dest = Join-Path $root $rel
        $old = Join-Path $backup $rel
        if (Test-Path -LiteralPath $dest) {
          New-Item -ItemType Directory -Path (Split-Path -Parent $old) -Force | Out-Null
          Copy-Item -LiteralPath $dest -Destination $old -Force
          $backed.Add($rel)
        }
        New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force | Out-Null
        Copy-Item -LiteralPath $_.FullName -Destination $dest -Force
        $written.Add($rel)
      }
      $settings.version = [string]$manifest.version
      $settings | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $settingsFile -Encoding UTF8
    } catch {
      foreach ($rel in $written) {
        $dest = Join-Path $root $rel
        if ($backed.Contains($rel)) { Copy-Item -LiteralPath (Join-Path $backup $rel) -Destination $dest -Force }
        else { Remove-Item -LiteralPath $dest -Force -ErrorAction SilentlyContinue }
      }
      throw
    }
    Notice "MaxxHQ updated to $($manifest.version). Your settings were preserved."
  } finally { Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue }
} catch {
  if (-not $Quiet) { Notice "Update was not installed.`n`n$($_.Exception.Message)" }
  else { Add-Content -LiteralPath (Join-Path $root 'Workspace-errors.log') -Value ((Get-Date -Format o) + ': UPDATE: ' + $_.Exception.Message) }
}
