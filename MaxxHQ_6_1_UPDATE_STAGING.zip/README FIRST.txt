﻿MAXXHQ V5 — DUAL MONITOR

1. Extract this ZIP fully.
2. Double-click OPEN MaxxHQ.vbs (not a .cmd file).
3. Your PING links are preset. Click a logo to open its website; click the rest of a tile to select its information.
4. Click LIVE SCRIPT to open the included local V17 script.
5. Settings saves application links; the website session remains in your normal Edge profile.

The approved graphical interface is included. This is not a fully tested release. The app shows no fake live agent statuses or hours. Live Gusto/EnrollHere integrations are NOT connected. Browser tabs/windows may still require manual layout.

If it fails, see Workspace-errors.log in this extracted folder.

Review V17.LiveCalls.html for personal test/caller information before sharing.

DUAL MONITOR UPDATE
Click the dashboard's Start Workspace button to launch the four-tab main browser on your primary monitor, plus SunFire (70%) and V17 (30%) on the right-hand monitor.
Close previously opened duplicate work windows before testing. Existing logins are retained in the normal Edge profile.
This arrangement has been statically inspected but requires testing on your Windows dual-monitor setup.

MAXXHQ SHORTCUT SETUP
Double-click INSTALL MaxxHQ SHORTCUT.vbs once to create the desktop shortcut. Right-click that desktop shortcut and select Pin to taskbar (on Windows 11, Show more options may be needed). Edge-hosted dashboard windows can still display the Edge icon on the active window; a native app wrapper is required to fully replace its running taskbar identity.
