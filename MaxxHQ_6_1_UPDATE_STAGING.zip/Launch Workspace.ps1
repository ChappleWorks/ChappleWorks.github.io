﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
try {
  $config = Get-Content -LiteralPath (Join-Path $root 'settings.json') -Raw | ConvertFrom-Json
  if ($config.checkUpdatesAtStartup -eq $true -and -not [string]::IsNullOrWhiteSpace([string]$config.updateManifestUrl)) {
    & (Join-Path $root 'Check MaxxHQ Updates.ps1') -Quiet
  }
  & (Join-Path $root 'Workspace Bridge.ps1')
} catch {
  $detail = $_.ToString()
  Add-Content -LiteralPath (Join-Path $root 'Workspace-errors.log') -Value ((Get-Date -Format o) + ': STARTUP: ' + $detail)
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show("MaxxHQ could not start. Details were saved in Workspace-errors.log.`r`n`r`n" + $_.Exception.Message, 'MaxxHQ - Startup Error', 'OK', 'Error') | Out-Null
}
