﻿try {
# PING Start Work V2 -- opens windows only, never clocks in or changes call status.
$ErrorActionPreference = 'Stop'
$homeFolder = Split-Path -Parent $MyInvocation.MyCommand.Path
$settings = Get-Content (Join-Path $homeFolder 'settings.json') -Raw | ConvertFrom-Json

$edges = @(
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "${env:ProgramFiles}\Microsoft\Edge\Application\msedge.exe",
  "${env:LOCALAPPDATA}\Microsoft\Edge\Application\msedge.exe"
)
$edge = $edges | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $edge) { throw 'Microsoft Edge is not installed where expected.' }

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Runtime.InteropServices;
public static class PingDesktopWindows {
    public delegate bool EnumCallback(IntPtr hwnd, IntPtr lparam);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumCallback callback, IntPtr lparam);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr hwnd, StringBuilder text, int length);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hwnd, int command);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr hwnd, IntPtr after, int x, int y, int width, int height, uint flags);
    public static long[] EdgeWindows() {
        var windows = new List<long>();
        EnumWindows((h, param) => {
            if (!IsWindowVisible(h)) return true;
            var title = new StringBuilder(512);
            if (GetWindowText(h, title, title.Capacity) == 0) return true;
            uint pid;
            GetWindowThreadProcessId(h, out pid);
            try {
                if(Process.GetProcessById((int)pid).ProcessName.Equals("msedge", StringComparison.OrdinalIgnoreCase))
                    windows.Add(h.ToInt64());
            } catch {}
            return true;
        }, IntPtr.Zero);
        return windows.ToArray();
    }
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr hwnd, out RECT rect);
    public static string Bounds(long handle) {
        RECT r; if (!GetWindowRect(new IntPtr(handle),out r)) return "unavailable";
        return String.Format("{0},{1} {2}x{3}",r.Left,r.Top,r.Right-r.Left,r.Bottom-r.Top);
    }
    public static void Place(long handle, int x, int y, int width, int height) {
        var h = new IntPtr(handle);
        ShowWindow(h, 9); // SW_RESTORE
        SetWindowPos(h, IntPtr.Zero, x, y, width, height, 0x0040); // SWP_SHOWWINDOW
    }
}
"@

function Open-PingWindow([string[]] $urls) {
    $before = @( [PingDesktopWindows]::EdgeWindows() )
    # --new-window creates an independent browser window, not a tab in your existing browsing.
    # Passing multiple URLs opens tabs inside that new PING window.
    Start-Process -FilePath $edge -ArgumentList (@('--new-window') + $urls)
    for ($n = 0; $n -lt 60; $n++) {
        Start-Sleep -Milliseconds 250
        $after = @( [PingDesktopWindows]::EdgeWindows() )
        $new = @($after | Where-Object { $before -notcontains $_ })
        if ($new.Count -gt 0) { return [long] $new[-1] }
    }
    Write-Warning 'Edge opened, but its new window could not be identified for positioning.'
    return [long] 0
}

# Work hub: a NEW Edge window containing normal work tabs.
$hub = @(
    [string]$settings.gustoUrl,
    [string]$settings.dialerUrl,
    [string]$settings.teamsUrl,
    [string]$settings.outlookUrl
)
$hubWindow = Open-PingWindow $hub

# Two NEW windows, allowing real desktop side-by-side tiling.
$sun = Open-PingWindow @([string]$settings.sunfireUrl)
$target = [string]$settings.scriptTarget
if (-not $target) { $target = 'V17.LiveCalls.html' }
if ($target -match '^https?://') { $guide = $target }
else {
 if (-not [System.IO.Path]::IsPathRooted($target)) { $target = Join-Path $homeFolder $target }
 if (-not (Test-Path -LiteralPath $target)) { throw "Script not found: $target" }
 $guide = ([System.Uri]::new($target)).AbsoluteUri
}
$scriptWindow = Open-PingWindow @($guide)

$screens = @([System.Windows.Forms.Screen]::AllScreens)
$primary = $screens | Where-Object { $_.Primary } | Select-Object -First 1
if (-not $primary) { $primary = $screens[0] }
# Use the display physically to the right of the primary, not an arbitrary Windows index.
$selectedScreen = $screens | Where-Object { $_.DeviceName -ne $primary.DeviceName -and $_.Bounds.Left -ge $primary.Bounds.Right } | Sort-Object { $_.Bounds.Left } | Select-Object -First 1
if (-not $selectedScreen) {
  $selectedScreen = $screens | Where-Object { $_.DeviceName -ne $primary.DeviceName } | Sort-Object { $_.Bounds.Left } -Descending | Select-Object -First 1
}
if (-not $selectedScreen) { $selectedScreen = $primary }
# The four-tab hub occupies the primary display's usable work area.
$primaryArea = $primary.WorkingArea
if ($hubWindow -ne 0) {
 [PingDesktopWindows]::Place($hubWindow,$primaryArea.X,$primaryArea.Y,$primaryArea.Width,$primaryArea.Height)
}
$workArea = $selectedScreen.WorkingArea
$pad = [Math]::Max(6,[Math]::Min(40,[int]$settings.monitorPadding))
$screen = New-Object System.Drawing.Rectangle(($workArea.X+$pad),($workArea.Y+$pad),($workArea.Width-2*$pad),($workArea.Height-2*$pad))
$pct = [Math]::Max(50, [Math]::Min(80, [int]$settings.sunfirePercent))
$gap = 8
$left = [int][Math]::Floor(($screen.Width - $gap) * $pct / 100)
$right = [int]($screen.Width - $gap - $left)
function Arrange-WorkWindows {
    if ($sun -ne 0) { [PingDesktopWindows]::Place($sun,$screen.X,$screen.Y,$left,$screen.Height) }
    if ($scriptWindow -ne 0) { [PingDesktopWindows]::Place($scriptWindow,$($screen.X + $left + $gap),$screen.Y,$right,$screen.Height) }
}
Arrange-WorkWindows
# Edge often restores its previous geometry after launch. Reapply while tabs finish loading.
for ($attempt = 0; $attempt -lt 9; $attempt++) {
 Start-Sleep -Milliseconds 900
 Arrange-WorkWindows
 if ($hubWindow -ne 0) { [PingDesktopWindows]::Place($hubWindow,$primaryArea.X,$primaryArea.Y,$primaryArea.Width,$primaryArea.Height) }
}
$placementLog = Join-Path $homeFolder 'PING-window-layout.log'
Add-Content -LiteralPath $placementLog -Value ('{0}: Monitor {1}, work area {2}, sun {3}, script {4}' -f (Get-Date -Format o),$selectedScreen.DeviceName,$workArea.ToString(),$(if($sun){[PingDesktopWindows]::Bounds($sun)}else{'not detected'}),$(if($scriptWindow){[PingDesktopWindows]::Bounds($scriptWindow)}else{'not detected'}))
Write-Host 'PING dual-monitor layout requested. See PING-window-layout.log for placement.'

} catch {
 Add-Content -LiteralPath (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'PING-errors.log') -Value ((Get-Date -Format o).ToString()+': '+ $_.ToString())
 Add-Type -AssemblyName System.Windows.Forms
 [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'PING Start Workspace error') | Out-Null
}
