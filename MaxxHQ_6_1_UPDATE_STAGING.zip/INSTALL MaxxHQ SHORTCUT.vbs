Option Explicit
Dim shell, fso, folder, link, desktop
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
desktop = shell.SpecialFolders("Desktop")
Set link = shell.CreateShortcut(desktop & "\MaxxHQ.lnk")
link.TargetPath = shell.ExpandEnvironmentStrings("%SystemRoot%") & "\System32\wscript.exe"
link.Arguments = Chr(34) & folder & "\OPEN MaxxHQ.vbs" & Chr(34)
link.WorkingDirectory = folder
link.IconLocation = folder & "\MaxxHQ-Desktop.ico,0"
link.Description = "Open MaxxHQ workspace"
link.Save
MsgBox "MaxxHQ desktop shortcut created." & vbCrLf & "Right-click the shortcut to pin it to your taskbar.", 64, "MaxxHQ"
